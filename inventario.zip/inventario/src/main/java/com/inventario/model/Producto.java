package com.inventario.model;

import jakarta.persistence.*;

@Entity
public class Producto {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    public Long id;
    public String nombre;
    public int stock;
    public int minimo; // por debajo de esto es "stock faltante"
    public double precio;

    public Producto() {}
    public Producto(String nombre, int stock, int minimo, double precio) {
        this.nombre = nombre; this.stock = stock; this.minimo = minimo; this.precio = precio;
    }
}
