package com.inventario.model;

import jakarta.persistence.*;

@Entity
public class Usuario {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    public Long id;
    @Column(unique = true)
    public String username;
    public String password;
    public String rol; // ADMIN, USUARIO, ALMACENISTA

    public Usuario() {}
    public Usuario(String username, String password, String rol) {
        this.username = username; this.password = password; this.rol = rol;
    }
}
