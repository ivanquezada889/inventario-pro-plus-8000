package com.inventario.model;

import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity
public class Pedido {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    public Long id;
    public String producto;
    public int cantidad;
    public String tipo;    // SALIDA (admin/usuario) o REPOSICION (almacenista)
    public String usuario;
    public LocalDateTime fecha = LocalDateTime.now();
}
