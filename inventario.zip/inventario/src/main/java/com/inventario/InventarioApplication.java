package com.inventario;

import com.inventario.model.*;
import com.inventario.repo.*;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

@SpringBootApplication
public class InventarioApplication {
    public static void main(String[] args) {
        SpringApplication.run(InventarioApplication.class, args);
    }

    // Datos iniciales (solo si la BD está vacía)
    @Bean
    CommandLineRunner seed(UsuarioRepo u, ProductoRepo p) {
        return args -> {
            if (u.count() == 0) {
                u.save(new Usuario("admin", "admin123", "ADMIN"));
                u.save(new Usuario("usuario", "user123", "USUARIO"));
                u.save(new Usuario("almacen", "almacen123", "ALMACENISTA"));
            }
            if (p.count() == 0) {
                p.save(new Producto("Teclado", 20, 5, 15.5));
                p.save(new Producto("Mouse", 3, 5, 8.0));
                p.save(new Producto("Monitor", 10, 4, 120.0));
            }
        };
    }
}
