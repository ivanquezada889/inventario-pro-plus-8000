package com.inventario.controller;

import com.inventario.model.*;
import com.inventario.repo.*;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;
import java.util.*;

@RestController
@RequestMapping("/api")
public class ApiController {
    private final UsuarioRepo usuarios;
    private final ProductoRepo productos;
    private final PedidoRepo pedidos;
    private final Map<String, Usuario> sesiones = new HashMap<>();

    public ApiController(UsuarioRepo u, ProductoRepo p, PedidoRepo d) {
        this.usuarios = u; this.productos = p; this.pedidos = d;
    }

    // Valida token y rol
    private Usuario auth(String token, String... roles) {
        Usuario u = token == null ? null : sesiones.get(token);
        if (u == null) throw new ResponseStatusException(HttpStatus.UNAUTHORIZED, "Sesión inválida");
        if (roles.length > 0 && !Arrays.asList(roles).contains(u.rol))
            throw new ResponseStatusException(HttpStatus.FORBIDDEN, "No tienes permiso");
        return u;
    }

    @PostMapping("/login")
    public Map<String, String> login(@RequestBody Map<String, String> b) {
        Usuario u = usuarios.findByUsername(b.get("username"))
            .filter(x -> x.password.equals(b.get("password")))
            .orElseThrow(() -> new ResponseStatusException(HttpStatus.UNAUTHORIZED, "Credenciales incorrectas"));
        String token = UUID.randomUUID().toString();
        sesiones.put(token, u);
        return Map.of("token", token, "rol", u.rol, "username", u.username);
    }

    // ---------- PRODUCTOS ----------
    @GetMapping("/productos")
    public List<Producto> listar(@RequestHeader(value = "X-Token", required = false) String t) {
        auth(t, "ADMIN", "ALMACENISTA");
        return productos.findAll();
    }

    // Catálogo para hacer pedidos (todos los roles)
    @GetMapping("/catalogo")
    public List<Producto> catalogo(@RequestHeader(value = "X-Token", required = false) String t) {
        auth(t);
        return productos.findAll();
    }

    @PostMapping("/productos")
    public Producto crear(@RequestHeader(value = "X-Token", required = false) String t, @RequestBody Producto p) {
        auth(t, "ADMIN"); p.id = null; return productos.save(p);
    }

    @PutMapping("/productos/{id}")
    public Producto modificar(@RequestHeader(value = "X-Token", required = false) String t,
                              @PathVariable Long id, @RequestBody Producto n) {
        auth(t, "ADMIN");
        Producto p = productos.findById(id).orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND));
        p.nombre = n.nombre; p.stock = n.stock; p.minimo = n.minimo; p.precio = n.precio;
        return productos.save(p);
    }

    @DeleteMapping("/productos/{id}")
    public void quitar(@RequestHeader(value = "X-Token", required = false) String t, @PathVariable Long id) {
        auth(t, "ADMIN"); productos.deleteById(id);
    }

    @GetMapping("/faltantes")
    public List<Producto> faltantes(@RequestHeader(value = "X-Token", required = false) String t) {
        auth(t, "ADMIN", "ALMACENISTA");
        return productos.findAll().stream().filter(p -> p.stock < p.minimo).toList();
    }

    // ---------- USUARIOS ----------
    @GetMapping("/usuarios")
    public List<Map<String, Object>> verUsuarios(@RequestHeader(value = "X-Token", required = false) String t) {
        auth(t, "ADMIN");
        return usuarios.findAll().stream()
            .map(u -> Map.<String, Object>of("id", u.id, "username", u.username, "rol", u.rol)).toList();
    }

    @PostMapping("/usuarios")
    public Map<String, String> crearUsuario(@RequestHeader(value = "X-Token", required = false) String t,
                                            @RequestBody Usuario u) {
        auth(t, "ADMIN");
        if (!List.of("ADMIN", "USUARIO", "ALMACENISTA").contains(u.rol))
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Rol inválido");
        if (usuarios.findByUsername(u.username).isPresent())
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "El usuario ya existe");
        u.id = null; usuarios.save(u);
        return Map.of("mensaje", "Usuario creado");
    }

    // ---------- PEDIDOS ----------
    @PostMapping("/pedidos")
    public Pedido pedir(@RequestHeader(value = "X-Token", required = false) String t,
                        @RequestBody Map<String, Number> b) {
        Usuario u = auth(t);
        Producto p = productos.findById(b.get("productoId").longValue())
            .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Producto no existe"));
        int cant = b.get("cantidad").intValue();
        if (cant <= 0) throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Cantidad inválida");

        Pedido d = new Pedido();
        d.producto = p.nombre; d.cantidad = cant; d.usuario = u.username;

        if (u.rol.equals("ALMACENISTA")) {
            // Solo puede reponer productos con stock faltante
            if (p.stock >= p.minimo)
                throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Ese producto no tiene stock faltante");
            p.stock += cant; d.tipo = "REPOSICION";
        } else {
            if (p.stock < cant)
                throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Stock insuficiente (" + p.stock + ")");
            p.stock -= cant; d.tipo = "SALIDA";
        }
        productos.save(p);
        return pedidos.save(d);
    }

    @GetMapping("/pedidos")
    public List<Pedido> verPedidos(@RequestHeader(value = "X-Token", required = false) String t) {
        Usuario u = auth(t);
        return u.rol.equals("ADMIN") ? pedidos.findAll()
            : pedidos.findAll().stream().filter(x -> x.usuario.equals(u.username)).toList();
    }
}
